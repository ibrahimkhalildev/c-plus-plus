// #include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{

    int n, q;

    // Time complexity O(n + q)

    for (int i = 0; i < n; i++)
    {
        cout << i << '\n';
    }
    for (int i = 0; i < q; i++)
    {
        cout << i << '\n';
    }

    return 0;
}
